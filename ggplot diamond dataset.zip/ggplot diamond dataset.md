

```R
install.packages("ggplot2")
```

    also installing the dependencies 'ps', 'processx', 'callr', 'prettyunits', 'backports', 'desc', 'pkgbuild', 'rprojroot', 'rstudioapi', 'pkgload', 'praise', 'lattice', 'colorspace', 'assertthat', 'utf8', 'testthat', 'nlme', 'Matrix', 'farver', 'labeling', 'lifecycle', 'munsell', 'R6', 'RColorBrewer', 'viridisLite', 'cli', 'ellipsis', 'fansi', 'magrittr', 'pillar', 'pkgconfig', 'vctrs', 'glue', 'gtable', 'isoband', 'MASS', 'mgcv', 'rlang', 'scales', 'tibble', 'withr'
    
    

    
      There is a binary version available but the source version is later:
              binary source needs_compilation
    backports  1.1.7  1.1.8              TRUE
    
      Binaries will be installed
    package 'ps' successfully unpacked and MD5 sums checked
    package 'processx' successfully unpacked and MD5 sums checked
    package 'callr' successfully unpacked and MD5 sums checked
    package 'prettyunits' successfully unpacked and MD5 sums checked
    package 'backports' successfully unpacked and MD5 sums checked
    package 'desc' successfully unpacked and MD5 sums checked
    package 'pkgbuild' successfully unpacked and MD5 sums checked
    package 'rprojroot' successfully unpacked and MD5 sums checked
    package 'rstudioapi' successfully unpacked and MD5 sums checked
    package 'pkgload' successfully unpacked and MD5 sums checked
    package 'praise' successfully unpacked and MD5 sums checked
    package 'lattice' successfully unpacked and MD5 sums checked
    package 'colorspace' successfully unpacked and MD5 sums checked
    package 'assertthat' successfully unpacked and MD5 sums checked
    package 'utf8' successfully unpacked and MD5 sums checked
    package 'testthat' successfully unpacked and MD5 sums checked
    package 'nlme' successfully unpacked and MD5 sums checked
    package 'Matrix' successfully unpacked and MD5 sums checked
    package 'farver' successfully unpacked and MD5 sums checked
    package 'labeling' successfully unpacked and MD5 sums checked
    package 'lifecycle' successfully unpacked and MD5 sums checked
    package 'munsell' successfully unpacked and MD5 sums checked
    package 'R6' successfully unpacked and MD5 sums checked
    package 'RColorBrewer' successfully unpacked and MD5 sums checked
    package 'viridisLite' successfully unpacked and MD5 sums checked
    package 'cli' successfully unpacked and MD5 sums checked
    package 'ellipsis' successfully unpacked and MD5 sums checked
    package 'fansi' successfully unpacked and MD5 sums checked
    package 'magrittr' successfully unpacked and MD5 sums checked
    package 'pillar' successfully unpacked and MD5 sums checked
    package 'pkgconfig' successfully unpacked and MD5 sums checked
    package 'vctrs' successfully unpacked and MD5 sums checked
    package 'glue' successfully unpacked and MD5 sums checked
    package 'gtable' successfully unpacked and MD5 sums checked
    package 'isoband' successfully unpacked and MD5 sums checked
    package 'MASS' successfully unpacked and MD5 sums checked
    package 'mgcv' successfully unpacked and MD5 sums checked
    package 'rlang' successfully unpacked and MD5 sums checked
    package 'scales' successfully unpacked and MD5 sums checked
    package 'tibble' successfully unpacked and MD5 sums checked
    package 'withr' successfully unpacked and MD5 sums checked
    package 'ggplot2' successfully unpacked and MD5 sums checked
    
    The downloaded binary packages are in
    	C:\Users\Adam Greenwood\AppData\Local\Temp\Rtmpyq7ig8\downloaded_packages
    


```R
library(ggplot2) # Loading the library.
data(diamonds) # Read and preview data.
head(diamonds)
```

    Warning message:
    "package 'ggplot2' was built under R version 3.6.3"


<table>
<thead><tr><th scope=col>carat</th><th scope=col>cut</th><th scope=col>color</th><th scope=col>clarity</th><th scope=col>depth</th><th scope=col>table</th><th scope=col>price</th><th scope=col>x</th><th scope=col>y</th><th scope=col>z</th></tr></thead>
<tbody>
	<tr><td>0.23     </td><td>Ideal    </td><td>E        </td><td>SI2      </td><td>61.5     </td><td>55       </td><td>326      </td><td>3.95     </td><td>3.98     </td><td>2.43     </td></tr>
	<tr><td>0.21     </td><td>Premium  </td><td>E        </td><td>SI1      </td><td>59.8     </td><td>61       </td><td>326      </td><td>3.89     </td><td>3.84     </td><td>2.31     </td></tr>
	<tr><td>0.23     </td><td>Good     </td><td>E        </td><td>VS1      </td><td>56.9     </td><td>65       </td><td>327      </td><td>4.05     </td><td>4.07     </td><td>2.31     </td></tr>
	<tr><td>0.29     </td><td>Premium  </td><td>I        </td><td>VS2      </td><td>62.4     </td><td>58       </td><td>334      </td><td>4.20     </td><td>4.23     </td><td>2.63     </td></tr>
	<tr><td>0.31     </td><td>Good     </td><td>J        </td><td>SI2      </td><td>63.3     </td><td>58       </td><td>335      </td><td>4.34     </td><td>4.35     </td><td>2.75     </td></tr>
	<tr><td>0.24     </td><td>Very Good</td><td>J        </td><td>VVS2     </td><td>62.8     </td><td>57       </td><td>336      </td><td>3.94     </td><td>3.96     </td><td>2.48     </td></tr>
</tbody>
</table>




```R
# Density plot - Visualizes the density of observations that fall under a certain range of values.
ggplot(diamonds) + geom_density(aes(x=carat), fill="purple") + xlab("Carat") + ylab("Density")
```


![png](output_2_0.png)



```R
# Scatter plot (object) - storing data as a ggplot object for future modification, this allows reuse of code or adding layers.
# Plot is based off of diamond color.
a <- ggplot(diamonds, aes(x=carat, y=price)) # Saving as variable a, adding aesthetic to carat and price.
a + geom_point(aes(color=color)) + xlab("Carat") + ylab("Price") # adding layer geom_point with color aesthetic and x,y labels.
```


![png](output_3_0.png)



```R
# Same plot based on clarity.
a <- ggplot(diamonds, aes(x=carat, y=price))
a + geom_point(aes(color=clarity)) + xlab("Carat") + ylab("Clarity")
```


![png](output_4_0.png)



```R
# Segmentation of scatter plot for color, carat & price.
# Seperating segments allows for further insight into features and interpretations of the dataset.
a + geom_point(aes(color=color)) + facet_wrap(~color) + xlab("Carat") + ylab("Price")
```


![png](output_5_0.png)



```R
# Segmentation of scatter plot based on clarity, carat & price.
a + geom_point(aes(color=clarity)) + facet_wrap(~color) + xlab("Carat") + ylab("Price")
```


![png](output_6_0.png)



```R
# Further Segmentation adding more dimensions & variables.
# Using the dataset object adding aesthetic of color to color vector, adding facet_layer for cut realtion to clarity. X & Y labels.
a + geom_point(aes(color=color)) + facet_wrap(cut ~ clarity) + xlab("Carat") + ylab("Price")
```


![png](output_7_0.png)



```R
# Separating out segmentations
# Instead of facet_wrap we use facet_grid this forms a matrix of panels defined by row and column faceting variables. I used cut and clarity.
a + geom_point(aes(color=color)) + facet_grid(cut ~ clarity) +xlab("Carat") +ylab("Price")
```


![png](output_8_0.png)



```R

```
